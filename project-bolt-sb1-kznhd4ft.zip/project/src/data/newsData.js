const newsData = [
  {
    id: 1,
    title: "Global Climate Summit Results in Historic Agreement",
    thumbnail: "https://images.pexels.com/photos/2990650/pexels-photo-2990650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "World leaders reach a groundbreaking climate agreement setting ambitious targets for carbon reduction over the next decade.",
    content: `In a landmark decision that signals a significant shift in global climate policy, world leaders from 195 countries have unanimously agreed to an unprecedented climate accord at this year's Global Climate Summit.

The agreement, which has been hailed as "historic" by environmental experts, establishes legally binding targets for carbon emission reductions, with the ambitious goal of limiting global warming to 1.5 degrees Celsius above pre-industrial levels by 2050.

"This represents a turning point in our collective fight against climate change," said UN Secretary-General Antonio Guterres. "For the first time, we have a truly global commitment with concrete, measurable targets and accountability mechanisms."

Key provisions of the agreement include:
- A 50% reduction in carbon emissions by 2030 compared to 2005 levels
- Complete phase-out of coal power in developed nations by 2035
- A $100 billion annual fund to help developing nations transition to renewable energy
- Mandatory climate risk disclosure for publicly traded companies

The agreement follows two weeks of intense negotiations, with many observers noting that increased public pressure and recent extreme weather events helped push reluctant nations toward consensus.

Environmental activists have cautiously welcomed the agreement while emphasizing the need for immediate action. "The targets are ambitious, which is exactly what we need," said Greta Thunberg. "But what matters now is implementation. These cannot be empty promises."

Markets responded positively to the news, with renewable energy stocks seeing significant gains as investors anticipate increased government investment in green technology.`,
    viewCount: 1243,
    likes: 89,
    dislikes: 12,
    comments: [
      { id: 1, username: "EcoWarrior", text: "Finally some real action! Let's hope they follow through.", timestamp: "2024-06-12T14:23:00Z" },
      { id: 2, username: "SkepticalScientist", text: "The targets are good, but we need stronger enforcement mechanisms.", timestamp: "2024-06-12T15:45:00Z" }
    ],
    category: "Environment",
    publicationDate: "2024-06-12T10:15:00Z"
  },
  {
    id: 2,
    title: "Revolutionary AI Model Can Diagnose 50 Medical Conditions from a Single Blood Sample",
    thumbnail: "https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "Researchers have developed an AI system capable of detecting dozens of diseases with 95% accuracy from standard blood tests.",
    content: `In a breakthrough that could transform medical diagnostics, researchers at Stanford Medical Center have unveiled an artificial intelligence system that can accurately diagnose more than 50 different medical conditions from a single blood sample.

The system, named MediScan, utilizes advanced machine learning algorithms to analyze standard blood test results and identify subtle patterns that may indicate the presence of diseases ranging from diabetes and heart disease to various forms of cancer and neurological disorders.

"What makes MediScan revolutionary is not just its accuracy, which exceeds 95% in clinical trials, but its ability to screen for so many conditions simultaneously from tests that are already routinely performed," explained Dr. Sarah Chen, lead researcher on the project.

The AI model was trained on an anonymized dataset of over 10 million blood test results, correlated with confirmed medical diagnoses. It identifies microscopic changes in blood composition that are invisible to the human eye but form distinctive patterns when analyzed computationally.

Medical professionals are cautiously optimistic about the technology's potential. "If widely implemented, this could dramatically reduce diagnostic delays, especially for conditions that often go undetected in early stages," said Dr. Robert Williams, who was not involved in the research but reviewed the published findings.

The technology is particularly promising for regions with limited access to medical specialists. A simple blood test analyzed by MediScan could help identify patients who need more specialized care, potentially saving millions of lives through early intervention.

The FDA has fast-tracked the system for review, and pending approval, it could be available in hospitals within 18 months. The researchers are also developing a scaled-down version that could be used in smaller clinics and rural healthcare facilities.

Privacy advocates have raised concerns about the massive amount of health data being processed by the AI, but the research team insists all data is anonymized and protected by multiple layers of security.`,
    viewCount: 856,
    likes: 122,
    dislikes: 5,
    comments: [
      { id: 1, username: "FutureMD", text: "This could be game-changing for early diagnosis. Amazing work!", timestamp: "2024-06-10T09:23:00Z" },
      { id: 2, username: "TechEthicist", text: "I worry about the privacy implications. Who owns the data?", timestamp: "2024-06-10T11:45:00Z" },
      { id: 3, username: "HealthPolicy", text: "The potential for healthcare equity is enormous if this becomes widely accessible.", timestamp: "2024-06-11T08:12:00Z" }
    ],
    category: "Health",
    publicationDate: "2024-06-10T08:30:00Z"
  },
  {
    id: 3,
    title: "Tech Giant Unveils Quantum Computing Platform for Public Use",
    thumbnail: "https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "Leading technology company opens access to its quantum computing system, allowing developers to explore applications beyond classical computing capabilities.",
    content: `In a move that could accelerate the quantum computing revolution, tech giant QuantumTech has announced the public release of its 128-qubit quantum computing platform, making it the most powerful quantum system accessible to developers outside specialized research institutions.

The platform, named "Horizon Q," represents a significant leap forward in quantum computing technology and will be available through a cloud-based interface, allowing researchers, companies, and independent developers to run complex computational problems that would be practically impossible to solve using traditional computers.

"Today marks the transition of quantum computing from a theoretical marvel to a practical tool," said Dr. Emma Rodriguez, QuantumTech's Chief Quantum Officer, during the announcement. "By democratizing access to quantum computing, we hope to catalyze innovations across industries that we haven't even imagined yet."

Quantum computers leverage the principles of quantum mechanics to perform calculations using qubits (quantum bits), which can exist in multiple states simultaneously, unlike classical bits that can only be either 0 or 1. This property enables quantum computers to solve certain types of problems exponentially faster than even the most powerful supercomputers.

Potential applications include:
- Revolutionary drug discovery through precise molecular simulation
- Optimization of complex logistical operations
- Advanced materials science research
- Climate modeling at unprecedented scales
- Breaking current encryption standards while developing quantum-resistant alternatives

The platform includes a specially designed programming language called QuantumScript that abstracts some of the complexity of quantum programming, making it more accessible to developers familiar with classical programming paradigms.

Industry experts have responded with excitement tempered by practical considerations. "This is undoubtedly a milestone," said quantum computing researcher Dr. James Chang. "However, we're still in the early days of understanding how to effectively utilize quantum advantages for real-world problems."

QuantumTech has also announced a $10 million grant program to support innovative projects using the platform, with particular emphasis on applications addressing pressing global challenges in healthcare, climate science, and sustainable energy.

Security analysts note that the advancement of quantum computing also accelerates the need for quantum-resistant cryptography, as sufficiently powerful quantum computers could theoretically break many of the encryption systems currently protecting sensitive data worldwide.`,
    viewCount: 723,
    likes: 67,
    dislikes: 8,
    comments: [
      { id: 1, username: "QuantumDev", text: "I've been waiting for this! Already signed up for beta access.", timestamp: "2024-06-08T16:28:00Z" },
      { id: 2, username: "CryptoExpert", text: "We need to accelerate quantum-resistant encryption development now.", timestamp: "2024-06-08T18:45:00Z" }
    ],
    category: "Technology",
    publicationDate: "2024-06-08T14:00:00Z"
  },
  {
    id: 4,
    title: "Archaeologists Discover Ancient City Beneath the Amazon Rainforest",
    thumbnail: "https://images.pexels.com/photos/4666754/pexels-photo-4666754.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "Using advanced LiDAR technology, researchers have uncovered evidence of a sophisticated urban civilization that thrived in the Amazon basin over 1,000 years ago.",
    content: `In a discovery that rewrites our understanding of pre-Columbian civilizations, archaeologists have uncovered the remains of a vast ancient city hidden beneath the dense vegetation of the Amazon rainforest. The finding challenges long-held beliefs about the Amazon's past and the sophistication of early societies in the region.

The lost city, estimated to have been home to over 100,000 people at its peak around 800-1000 CE, was detected using LiDAR (Light Detection and Ranging) technology, which can penetrate the forest canopy to reveal ground structures invisible to the naked eye.

"What we've found is nothing short of revolutionary," said Dr. Maria Fernandez, lead archaeologist of the international team behind the discovery. "This wasn't just a settlement, but a complex urban center with monumental architecture, sophisticated water management systems, and evidence of advanced agricultural practices."

The city spans approximately 30 square kilometers and includes:
- A central ceremonial district with pyramids reaching 30 meters in height
- An intricate network of canals and reservoirs for water management
- Grid-patterned residential areas suggesting careful urban planning
- Agricultural terraces and raised fields designed to manage the challenging rainforest environment

Artifacts recovered from initial excavations include elaborate ceramics, stone tools, and gold ornaments suggesting a wealthy, stratified society with extensive trade networks reaching to the Andes and possibly beyond.

The discovery fundamentally challenges the notion that the Amazon was sparsely populated by small, nomadic tribes before European contact. Instead, it suggests the region supported large, sophisticated societies that significantly modified their environment while maintaining sustainable practices.

"These people weren't just surviving in the rainforest – they were thriving and transforming it," explained environmental archaeologist Dr. Robert Thompson. "They created a human-modified landscape that actually enhanced biodiversity in certain ways."

The finding also has implications for contemporary conservation efforts, suggesting that parts of the Amazon that appear pristine may actually be "cultural forests" – landscapes shaped by centuries of human management that only reverted to their current state after population collapse following European contact and the spread of diseases.

Indigenous representatives from the region have welcomed the discovery while emphasizing their ongoing connection to these ancestral lands. "Our oral histories speak of great cities and ancient knowledge," said Indigenous leader Paulo Mendes. "This discovery validates what our elders have always told us about our past."

The research team is working closely with Indigenous communities and Brazilian authorities to plan further research while ensuring the site's protection from looters and unauthorized development.`,
    viewCount: 542,
    likes: 78,
    dislikes: 3,
    comments: [
      { id: 1, username: "HistoryBuff", text: "This completely changes our understanding of pre-Columbian Amazon societies!", timestamp: "2024-06-05T11:23:00Z" },
      { id: 2, username: "Anthropologist101", text: "I'm particularly interested in how they managed such large-scale agriculture in that environment.", timestamp: "2024-06-05T13:17:00Z" }
    ],
    category: "Science",
    publicationDate: "2024-06-05T09:45:00Z"
  },
  {
    id: 5,
    title: "Major Breakthrough in Nuclear Fusion Could Revolutionize Clean Energy",
    thumbnail: "https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "Scientists achieve sustained nuclear fusion reaction with net energy gain, marking a critical milestone toward limitless clean energy.",
    content: `Scientists at the International Fusion Research Facility (IFRF) have announced a historic breakthrough in nuclear fusion technology, achieving a sustained fusion reaction that produced more energy than was required to initiate it – a milestone known as "ignition" that has eluded researchers for decades.

The experiment, conducted last week and verified through rigorous analysis, maintained the fusion reaction for 8.2 minutes and generated approximately 1.5 times more energy than was input – the first confirmed case of significant net energy gain in a controlled fusion experiment.

"This is the fusion equivalent of the Wright brothers' first flight," said Dr. Hiroshi Yamamoto, director of the IFRF. "We've proven that the fundamental concept works. Now begins the engineering journey to scale this into a practical power source."

Nuclear fusion – the same process that powers the sun – involves forcing atomic nuclei together to form heavier elements, releasing enormous amounts of energy in the process. Unlike current nuclear power plants, which rely on fission (the splitting of atoms), fusion produces no long-lived radioactive waste and uses abundant fuel sources like deuterium, which can be extracted from seawater.

The breakthrough came through a combination of advances in superconducting magnets, plasma containment technology, and precise control systems that allowed researchers to maintain the extreme conditions necessary for fusion – temperatures exceeding 100 million degrees Celsius and intense pressure – for an unprecedented duration.

Energy experts are cautiously celebrating the achievement. "This is unquestionably a historic milestone," said energy policy analyst Dr. Sarah Mitchell. "However, we should be clear that commercial fusion power plants are still likely 15-20 years away. There remains a substantial gap between a successful laboratory demonstration and a practical power plant."

Nevertheless, the achievement has already triggered increased investment in fusion technology. Hours after the announcement, a coalition of governments pledged an additional $30 billion toward fusion research and development over the next decade, while private fusion startups reported a surge in venture capital interest.

Environmental groups have generally welcomed the news, though some express concern about resources being diverted from more immediately deployable renewable energy solutions. "Fusion may be the perfect energy source for the future, but we can't wait for it to address climate change," said Greenpeace spokesperson Julia Chen. "We need to continue aggressive deployment of wind, solar, and other existing clean energy technologies."

The IFRF, a collaborative project supported by 35 nations, has published their complete findings in the journal Science, with unusually open access to their methodologies to accelerate global research in the field.`,
    viewCount: 912,
    likes: 145,
    dislikes: 7,
    comments: [
      { id: 1, username: "EnergyExpert", text: "Finally! I've been following fusion research for decades. This is the real deal.", timestamp: "2024-06-15T10:12:00Z" },
      { id: 2, username: "ClimateActivist", text: "Great news but we still need to focus on renewable energy for the immediate crisis.", timestamp: "2024-06-15T11:34:00Z" },
      { id: 3, username: "PhysicsTeacher", text: "Going to use this to inspire my students about the power of scientific persistence!", timestamp: "2024-06-16T08:45:00Z" }
    ],
    category: "Science",
    publicationDate: "2024-06-15T08:00:00Z"
  },
  {
    id: 6,
    title: "Historic Peace Treaty Ends 30-Year Regional Conflict",
    thumbnail: "https://images.pexels.com/photos/4307869/pexels-photo-4307869.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    summary: "After decades of hostilities, rival nations sign comprehensive peace agreement ensuring stability and cooperation in the region.",
    content: `In a ceremony described by observers as "emotional" and "historic," leaders from the nations of Easteria and Westland signed a comprehensive peace treaty today, officially ending a conflict that has claimed over 200,000 lives and displaced millions over three decades.

The treaty, signed in the neutral city of Geneva under UN supervision, addresses territorial disputes, establishes demilitarized zones, and creates frameworks for economic cooperation between the former enemies.

"Today marks not the end of our journey, but its true beginning," said Easterian President Mira Novak, who lost her own brother in the conflict. "We choose to break the cycle of violence that has consumed a generation and instead build a future our children deserve."

Westland Prime Minister Karim Abboud echoed these sentiments: "There comes a time when we must ask ourselves what we are fighting for, and whether the cost in human suffering can ever be justified. Today, we choose peace, reconciliation, and shared prosperity."

Key provisions of the treaty include:
- Resolution of disputed territories through a combination of new borders and special administrative zones
- A phased withdrawal of troops from conflict areas, to be monitored by UN peacekeepers
- Establishment of a joint commission to address refugee resettlement and compensation
- Creation of a $50 billion regional development fund supported by international donors
- Provisions for cultural exchanges and family reunification programs

The path to peace accelerated 18 months ago following catastrophic flooding that affected both nations, leading to unprecedented cooperation in disaster response. Informal talks between mid-level officials eventually expanded to direct negotiations between national leaders.

Citizens in both countries celebrated the announcement with spontaneous gatherings in major cities. In Easteria's capital, thousands gathered in Central Square, lighting candles and singing traditional songs. Similar scenes unfolded in Westland's major cities.

International reaction has been overwhelmingly positive, with the UN Secretary-General calling it "a testament to the power of dialogue and compromise." Major powers have pledged support for reconstruction efforts.

Nevertheless, analysts caution that implementing the agreement will face challenges, particularly from hardline factions on both sides who oppose compromise. Security remains tight around government buildings in both nations.

"Peace agreements are beginning points, not endings," noted conflict resolution expert Dr. Helena Morin. "The difficult work of reconciliation, rebuilding trust, and creating shared institutions lies ahead. But today represents a courageous first step."`,
    viewCount: 635,
    likes: 103,
    dislikes: 11,
    comments: [
      { id: 1, username: "PeaceAdvocate", text: "This brings me to tears. My family fled the conflict 20 years ago. Maybe we can return home now.", timestamp: "2024-06-18T15:23:00Z" },
      { id: 2, username: "HistoryProfessor", text: "A remarkable achievement given the complexity of this conflict. Implementation will be the true test.", timestamp: "2024-06-18T16:45:00Z" }
    ],
    category: "World",
    publicationDate: "2024-06-18T13:30:00Z"
  }
];

export default newsData;