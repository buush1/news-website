import React, { useContext, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArticleContext } from '../context/ArticleContext';
import ArticleCard from '../components/ArticleCard';
import Sidebar from '../components/Sidebar';
import { Calendar, Eye, ArrowRight } from 'lucide-react';
import '../styles/home.css';

const Home = () => {
  const { articles } = useContext(ArticleContext);
  const [featuredArticle, setFeaturedArticle] = useState(null);
  const [latestArticles, setLatestArticles] = useState([]);
  
  useEffect(() => {
    if (articles && articles.length > 0) {
      // Get the most recent article for the featured spot
      const sortedArticles = [...articles].sort((a, b) => 
        new Date(b.publicationDate) - new Date(a.publicationDate)
      );
      setFeaturedArticle(sortedArticles[0]);
      
      // Get the next 6 most recent articles for the grid
      setLatestArticles(sortedArticles.slice(1, 7));
    }
  }, [articles]);
  
  // Format the publication date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  if (!featuredArticle) {
    return <div className="container">Loading...</div>;
  }
  
  return (
    <main className="home">
      <div className="container">
        <header className="home-header">
          <h1 className="home-title">Stay Informed with EverydayTalk</h1>
          <p className="home-subtitle">
            Your trusted source for timely news and insightful stories from around the globe.
          </p>
        </header>
        
        <section className="featured-section">
          <div className="featured-article">
            <img src={featuredArticle.thumbnail} alt={featuredArticle.title} className="featured-image" />
            <div className="featured-content">
              <span className="featured-category">{featuredArticle.category}</span>
              <h2 className="featured-title">{featuredArticle.title}</h2>
              <p className="featured-summary">{featuredArticle.summary}</p>
              <div className="featured-meta">
                <div className="featured-info">
                  <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)', marginRight: 'var(--spacing-4)' }}>
                    <Calendar size={16} />
                    {formatDate(featuredArticle.publicationDate)}
                  </span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)' }}>
                    <Eye size={16} />
                    {featuredArticle.viewCount} views
                  </span>
                </div>
                <Link to={`/article/${featuredArticle.id}`} className="read-more">
                  Read Full Story <ArrowRight size={16} />
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        <div className="main-layout">
          <section className="articles-section">
            <h2 className="section-heading">Latest News</h2>
            <div className="articles-grid">
              {latestArticles.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          </section>
          
          <Sidebar />
        </div>
      </div>
    </main>
  );
};

export default Home;