import React, { useContext, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { ArticleContext } from '../context/ArticleContext';
import Comment from '../components/Comment';
import CommentForm from '../components/CommentForm';
import LikeDislikeButtons from '../components/LikeDislikeButtons';
import Sidebar from '../components/Sidebar';
import { Calendar, Eye, MessageSquare } from 'lucide-react';
import '../styles/article-detail.css';

const ArticleDetail = () => {
  const { id } = useParams();
  const { 
    getArticle, 
    incrementViews, 
    handleReaction, 
    addComment 
  } = useContext(ArticleContext);
  
  const article = getArticle(id);
  
  // Increment view count when component mounts
  useEffect(() => {
    if (article) {
      incrementViews(id);
    }
  }, [id, article, incrementViews]);
  
  // Format the publication date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  const handleCommentSubmit = (comment) => {
    addComment(id, comment);
  };
  
  if (!article) {
    return <div className="container">Article not found</div>;
  }
  
  return (
    <main className="article-detail">
      <div className="container">
        <div className="detail-layout">
          <div className="article-container">
            <header className="article-header">
              <span className="article-category">{article.category}</span>
              <h1 className="article-title">{article.title}</h1>
              <div className="article-meta">
                <span className="meta-item">
                  <Calendar size={16} />
                  {formatDate(article.publicationDate)}
                </span>
                <span className="meta-item">
                  <Eye size={16} />
                  {article.viewCount} views
                </span>
                <span className="meta-item">
                  <MessageSquare size={16} />
                  {article.comments.length} comments
                </span>
              </div>
            </header>
            
            <div className="article-featured-image">
              <img src={article.thumbnail} alt={article.title} />
            </div>
            
            <div className="article-content">
              {article.content.split('\n\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
            
            <div className="article-engagement">
              <div className="engagement-views">
                <Eye size={20} />
                <span>{article.viewCount} people have read this article</span>
              </div>
              
              <LikeDislikeButtons 
                articleId={article.id}
                likes={article.likes}
                dislikes={article.dislikes}
                onReaction={handleReaction}
              />
            </div>
            
            <section className="comments-section">
              <h3 className="comments-header">
                <MessageSquare size={24} />
                Comments ({article.comments.length})
              </h3>
              
              {article.comments.length > 0 ? (
                <ul className="comments-list">
                  {article.comments.map(comment => (
                    <Comment key={comment.id} comment={comment} />
                  ))}
                </ul>
              ) : (
                <p>No comments yet. Be the first to share your thoughts!</p>
              )}
              
              <CommentForm onSubmit={handleCommentSubmit} />
            </section>
          </div>
          
          <Sidebar />
        </div>
      </div>
    </main>
  );
};

export default ArticleDetail;