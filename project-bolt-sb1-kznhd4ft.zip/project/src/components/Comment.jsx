import React from 'react';

const Comment = ({ comment }) => {
  // Format the comment timestamp
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      // Today - show hours
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      return `Today at ${hours}:${minutes}`;
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      // More than a week - show date
      const options = { year: 'numeric', month: 'short', day: 'numeric' };
      return date.toLocaleDateString(undefined, options);
    }
  };

  return (
    <li className="comment">
      <div className="comment-header">
        <span className="comment-author">{comment.username}</span>
        <span className="comment-time">{formatTimestamp(comment.timestamp)}</span>
      </div>
      <p className="comment-content">{comment.text}</p>
    </li>
  );
};

export default Comment;