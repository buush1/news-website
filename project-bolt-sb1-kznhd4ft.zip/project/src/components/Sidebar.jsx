import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { ArticleContext } from '../context/ArticleContext';
import { TrendingUp as Trending, Tag } from 'lucide-react';
import '../styles/sidebar.css';

const Sidebar = () => {
  const { getTrendingArticles, getArticlesByCategory } = useContext(ArticleContext);
  const trendingArticles = getTrendingArticles();
  
  // Get unique categories
  const allArticles = getArticlesByCategory();
  const categories = [...new Set(allArticles.map(article => article.category))];
  
  // Format the publication date
  const formatDate = (dateString) => {
    const options = { month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-section trending-section">
        <h3 className="sidebar-heading">
          <Trending size={20} />
          Trending Now
        </h3>
        <ul className="trending-list">
          {trendingArticles.map(article => (
            <li key={article.id} className="trending-item">
              <Link to={`/article/${article.id}`} className="trending-link">
                <div className="trending-image">
                  <img src={article.thumbnail} alt={article.title} />
                </div>
                <div className="trending-content">
                  <h4 className="trending-title">{article.title}</h4>
                  <div className="trending-meta">
                    <span>{formatDate(article.publicationDate)}</span>
                    <span>{article.viewCount} views</span>
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="sidebar-section categories-section">
        <h3 className="sidebar-heading">
          <Tag size={20} />
          Categories
        </h3>
        <ul className="categories-list">
          {categories.map(category => (
            <li key={category} className="category-item">
              <Link to={`/category/${category.toLowerCase()}`} className="category-link">
                {category}
              </Link>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="sidebar-section subscribe-section">
        <h3 className="sidebar-heading">
          Stay Updated
        </h3>
        <p>Subscribe to our newsletter for daily updates</p>
        <form onSubmit={(e) => e.preventDefault()} className="sidebar-form">
          <input 
            type="email" 
            placeholder="Your email address" 
            className="sidebar-input"
          />
          <button type="submit" className="sidebar-button">
            Subscribe
          </button>
        </form>
      </div>
    </aside>
  );
};

export default Sidebar;