import React, { useState, useContext } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ThemeContext } from '../context/ThemeContext';
import { Newspaper, Moon, Sun, Menu, X } from 'lucide-react';
import '../styles/header.css';

const Header = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <header className="header">
      <div className="container header-container">
        <Link to="/" className="logo">
          <span className="logo-icon"><Newspaper size={24} /></span>
          <span>EverydayTalk</span>
        </Link>
        
        <nav className="nav">
          <ul className="nav-list">
            <li className="nav-item">
              <NavLink to="/" end>Home</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/category/world">World</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/category/technology">Technology</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/category/science">Science</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/category/health">Health</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/category/environment">Environment</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/profile">Profile</NavLink>
            </li>
          </ul>
        </nav>
        
        <div className="header-actions">
          <button 
            className="theme-toggle" 
            onClick={toggleTheme}
            aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
          >
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          
          <button 
            className="mobile-menu-toggle" 
            onClick={toggleMenu}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {menuOpen && (
        <div className="mobile-menu">
          <nav>
            <ul className="nav-list">
              <li className="nav-item">
                <NavLink to="/" end onClick={() => setMenuOpen(false)}>Home</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/category/world" onClick={() => setMenuOpen(false)}>World</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/category/technology" onClick={() => setMenuOpen(false)}>Technology</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/category/science" onClick={() => setMenuOpen(false)}>Science</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/category/health" onClick={() => setMenuOpen(false)}>Health</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/category/environment" onClick={() => setMenuOpen(false)}>Environment</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/profile" onClick={() => setMenuOpen(false)}>Profile</NavLink>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;