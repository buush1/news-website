import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Mail } from 'lucide-react';
import '../styles/footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-container">
          <div className="footer-section">
            <h4>EverydayTalk</h4>
            <p>Your trusted source for the latest news and insights from around the world. We deliver fact-checked, balanced reporting.</p>
            <div className="footer-social">
              <a href="#" aria-label="Facebook" className="social-icon"><Facebook size={20} /></a>
              <a href="#" aria-label="Twitter" className="social-icon"><Twitter size={20} /></a>
              <a href="#" aria-label="Instagram" className="social-icon"><Instagram size={20} /></a>
              <a href="#" aria-label="LinkedIn" className="social-icon"><Linkedin size={20} /></a>
            </div>
          </div>
          
          <div className="footer-section">
            <h4>Categories</h4>
            <ul className="footer-links">
              <li><Link to="/category/world">World</Link></li>
              <li><Link to="/category/technology">Technology</Link></li>
              <li><Link to="/category/science">Science</Link></li>
              <li><Link to="/category/health">Health</Link></li>
              <li><Link to="/category/environment">Environment</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4>Company</h4>
            <ul className="footer-links">
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/team">Our Team</Link></li>
              <li><Link to="/careers">Careers</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4>Subscribe</h4>
            <p>Get the latest news delivered to your inbox. We promise not to spam you.</p>
            <div className="subscribe-form">
              <form onSubmit={(e) => e.preventDefault()}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <input 
                    type="email" 
                    placeholder="Your email address"
                    style={{
                      padding: '0.5rem',
                      borderRadius: '4px 0 0 4px',
                      border: 'none',
                      width: '100%'
                    }}
                  />
                  <button 
                    type="submit"
                    style={{
                      background: 'var(--color-accent)',
                      color: 'white',
                      border: 'none',
                      borderRadius: '0 4px 4px 0',
                      padding: '0.5rem',
                      display: 'flex'
                    }}
                  >
                    <Mail size={20} />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; {currentYear} EverydayTalk. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;