import React from 'react';
import { Link } from 'react-router-dom';
import { Eye, Calendar } from 'lucide-react';
import '../styles/article-card.css';

const ArticleCard = ({ article }) => {
  // Format the publication date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <article className="article-card">
      <Link to={`/article/${article.id}`} className="article-image">
        <img src={article.thumbnail} alt={article.title} />
        <span className="article-category">{article.category}</span>
      </Link>
      <div className="article-content">
        <h3 className="article-title">
          <Link to={`/article/${article.id}`}>{article.title}</Link>
        </h3>
        <p className="article-summary">{article.summary}</p>
        <div className="article-meta">
          <span className="article-date">
            <Calendar size={14} />
            {formatDate(article.publicationDate)}
          </span>
          <span className="article-views">
            <Eye size={14} className="view-icon" />
            {article.viewCount}
          </span>
        </div>
      </div>
    </article>
  );
};

export default ArticleCard;